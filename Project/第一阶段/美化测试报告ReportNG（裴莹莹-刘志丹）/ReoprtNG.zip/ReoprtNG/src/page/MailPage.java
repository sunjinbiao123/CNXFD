package page;

import java.util.Map;

public class MailPage{
	public MailPage() {
		// TODO Auto-generated constructor stub
	}

	public String run(Map context) {
		// TODO Auto-generated method stub
		return null;
	}
}
